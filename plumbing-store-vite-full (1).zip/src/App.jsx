import React from 'react';

const products = [
  { id: 1, name: "მილი PVC 20მმ", description: "მაღალი ხარისხის წყლის მილი", price: "5₾" },
  { id: 2, name: "მილი PVC 25მმ", description: "მტკიცე და გამძლე", price: "7₾" },
  { id: 3, name: "კუთხე 90° 20მმ", description: "წყლის მილებისთვის", price: "2₾" },
  { id: 4, name: "კუთხე 90° 25მმ", description: "ხარისხიანი კუთხე", price: "3₾" },
  { id: 5, name: "სარქველი ½''", description: "მეტალის სარქველი", price: "10₾" },
  { id: 6, name: "წყლის ნიჩაბი", description: "მარტივი მონტაჟის ხელსაწყო", price: "15₾" }
];

export default function App() {
  return (
    <div>
      <header>
        <h1>სანტექნიკის მაღაზია</h1>
      </header>
      <main>
        <div className="grid">
          {products.map(p => (
            <div key={p.id} className="card">
              <h3>{p.name}</h3>
              <p>{p.description}</p>
              <strong>{p.price}</strong>
            </div>
          ))}
        </div>
      </main>
      <footer>
        <p>© 2025 Plumbing Store. ყველა უფლება დაცულია.</p>
      </footer>
    </div>
  );
}