# Plumbing Store Vite + React

ეს არის სანტექნიკის მაღაზიის ვებსაიტის საწყისი ვერსია Vite + React-ზე.

## გაშვება ლოკალურად

```bash
npm install
npm run dev
```
