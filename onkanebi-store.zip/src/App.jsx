import React from 'react'

export default function App() {
  return (
    <div style={{ textAlign: 'center', padding: '40px' }}>
      <h1>ონლაინ მაღაზია</h1>
      <p>ეს არის საწყისი ვერსია შენი პროექტის 🚀</p>
    </div>
  )
}
