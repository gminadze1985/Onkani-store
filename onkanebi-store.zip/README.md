# ონლაინ მაღაზია

ეს არის მარტივი React + Vite პროექტი ონლაინ მაღაზიისთვის.

## როგორ გავუშვათ ლოკალურად
```
npm install
npm run dev
```

## Deployment
აპლოდერეთ GitHub-ზე და გაუშვით Vercel-ზე.
